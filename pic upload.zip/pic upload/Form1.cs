﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//library use
using System.Data.SqlClient;
using System.IO;

namespace pic_upload
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }


        //database connection
        SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\ACER\Documents\Visual Studio 2013\Projects\pic upload\pic upload\Database1.mdf;Integrated Security=True");

        string imgLocation;
        SqlCommand cmd;


        //image select button
        private void button1_Click(object sender, EventArgs e)
        {

            OpenFileDialog imgOpen = new OpenFileDialog();
            imgOpen.Filter = "Image Files (*.jpg)|*.jpg | All Files (*.*)|*.*";


            if (imgOpen.ShowDialog() == DialogResult.OK)
            {
                imgLocation = imgOpen.FileName.ToString();
                pictureBox1.ImageLocation = imgLocation;

                
            }

        }

        
        //image save button
        private void button3_Click(object sender, EventArgs e)
        {

            byte[] images = null;
            FileStream Streem = new FileStream(imgLocation, FileMode.Open, FileAccess.Read);
            BinaryReader brs = new BinaryReader(Streem);
            images = brs.ReadBytes((int)Streem.Length);

            con.Open();
            string query = "INSERT INTO pro_img (Id,Image) VALUES ('" + textBox1.Text + "',@images)";
            cmd = new SqlCommand(query,con);
            cmd.Parameters.Add(new SqlParameter("@images", images));
            int N = cmd.ExecuteNonQuery();
            con.Close();

            MessageBox.Show(N.ToString()+"Data saved successfull");

        }

        //image view button
        private void button2_Click(object sender, EventArgs e)
        {

            con.Open();
            string query = "SELECT * FROM pro_img WHERE Id = '" + textBox1.Text + "'";
            cmd = new SqlCommand(query, con);
            SqlDataReader DataRead = cmd.ExecuteReader();
            DataRead.Read();

            if (DataRead.HasRows)
            {
                //textBox2.Text = DataRead[0].ToString();
                byte[] images = ((byte[])DataRead[1]);



                if (images == null)
                {
                    pictureBox1.Image = null;
                }
                else
                {
                    MemoryStream mstreem = new MemoryStream(images);
                    pictureBox1.Image = Image.FromStream(mstreem);

                }

            }
            else
            {

                MessageBox.Show("This Image not Available..!");

            }

            con.Close();

        }


    }
}
